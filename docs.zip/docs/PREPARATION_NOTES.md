# Repository preparation notes

## Changes

- Organized source files under `src/`; serial source content is unchanged apart from line-ending normalization.
- Corrected six CUDA macro formatting errors: `BALL_RADIUS`, `RESTITUTION`, `EXTRA_HIT_SPEED`, `TABLE_WIDTH`, `CUSHION_RESTITUTION`, and `TABLE_TOP_VERTS` were joined to their values.
- Normalized all six CUDA launch delimiters from `<< < ... >> >` to `<<< ... >>>`.
- Added English documentation, an optional CUDA CMake target, a gitignore, and report-derived CSV results.
- Copied the original report and presentation without changing their contents.

No physics algorithm, benchmark loop, benchmark duration, precision, or reported measurement was changed. No license was imposed.

## Checks and limits

Checked expected CUDA text repairs, serial source equivalence, byte equality of accompanying documents, result ratios, and ZIP integrity. No executable was built or run. Compilation and runtime behavior require local verification with CUDA/OpenGL dependencies.
