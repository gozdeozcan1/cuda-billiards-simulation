
#include <GL/glut.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <chrono>


const double BALL_RADIUS = 0.0305;
const double BALL_MASS = 0.205;
const double INERTIA_COEFF = 2.0 / 5.0;
const double BALL_BALL_MU = 0.05;
const double RESTITUTION = 0.95;
const double ROLLING_FRICTION = 0.01;
const double SLIDING_TABLE_MU = 0.10;
const double INITIAL_CUE_SPEED = 0.80;
const double CUSHION_RESTITUTION = 0.96;

const int BALL_COUNT = 10;
const double PI = 3.14;
const int COLLISION_PAIR_COUNT = BALL_COUNT * (BALL_COUNT - 1) / 2;
const double EXTRA_HIT_SPEED = 0.80;
const double TABLE_LENGTH = 2.40;
const double TABLE_WIDTH = 1.20;
const double STOP_SPEED = 0.004;
const double TIME_STEP = 1.0 / 240.0;
const int PHYSICS_STEPS_PER_FRAME = 3;
const double BENCHMARK_DURATION_SECONDS = 50.0;
const int TOTAL_RUNS = 1;
int currentRun = 0;
double avgPhysicsSteps = 0.0;
double avgSimSeconds = 0.0;
double avgPhysicsTime = 0.0;
double avgRenderingTime = 0.0;




struct Vec2 {
	double x, z;

	Vec2() : x(0), z(0) {}
	Vec2(double X, double Z) : x(X), z(Z) {}

	Vec2 operator+(const Vec2& b) const { return Vec2(x + b.x, z + b.z); }
	Vec2 operator-(const Vec2& b) const { return Vec2(x - b.x, z - b.z); }
	Vec2 operator*(double s) const { return Vec2(x * s, z * s); }
	Vec2 operator/(double s) const { return Vec2(x / s, z / s); }

	Vec2& operator+=(const Vec2& b) { x += b.x; z += b.z; return *this; }
	Vec2& operator-=(const Vec2& b) { x -= b.x; z -= b.z; return *this; }
	Vec2& operator*=(double s) { x *= s; z *= s; return *this; }
};



double dot2(Vec2 a, Vec2 b) {
	return a.x * b.x + a.z * b.z;
}

double length2(Vec2 a) {
	return std::sqrt(dot2(a, a));
}

Vec2 normalize2(Vec2 a) {
	double len = length2(a);
	if (len < 1e-12) return Vec2(1, 0);
	return a / len;
}



struct Ball {
	Vec2 pos;
	Vec2 vel;
	double omegaY;
	double rotAngle;
	float color[3];
};

Ball balls[BALL_COUNT];

double simulationTime = 0.0;
double realStartTime = 0.0;
double realEndTime = 0.0;
long long totalFrameCount = 0;
long long totalFrameCountSum = 0;
double physicsCalculationTime = 0.0;
double renderingTime = 0.0;
long long totalPhysicsSteps = 0;
long long totalCollisionChecks = 0;
double physicsStepsPerSecond = 0.0;
double simulatedSecondsPerSecond = 0.0;
bool simulationFinished = false;
bool resultPrinted = false;
int windowW = 1280;
int windowH = 720;
long long totalPhysicsStepsSum = 0;



double getRealTimeSeconds()
{
	using namespace std::chrono;

	static auto start =
		high_resolution_clock::now();

	auto now =
		high_resolution_clock::now();

	return duration<double>(now - start).count();
}


void setBallColor(int i) {

	if (i == 0) {
		balls[i].color[0] = 1.0f;
		balls[i].color[1] = 1.0f;
		balls[i].color[2] = 1.0f;
		return;
	}

	float colors[9][3] = {
		{1.00f, 0.90f, 0.20f},
		{0.20f, 0.35f, 1.00f},
		{1.00f, 0.20f, 0.20f},
		{0.70f, 0.25f, 1.00f},
		{1.00f, 0.60f, 0.10f},
		{0.20f, 0.85f, 0.20f},
		{0.70f, 0.15f, 0.15f},
		{0.25f, 0.35f, 0.90f},
		{1.00f, 0.65f, 1.00f}
	};

	balls[i].color[0] = colors[i - 1][0];
	balls[i].color[1] = colors[i - 1][1];
	balls[i].color[2] = colors[i - 1][2];
}
 
void createBalls() {



	for (int i = 0; i < BALL_COUNT; ++i) {
		balls[i].vel = Vec2(0, 0);
		balls[i].omegaY = 0.0;
		balls[i].rotAngle = 0.0;
		setBallColor(i);
	}

	balls[0].pos = Vec2(-0.80, 0.0);
	balls[0].vel = Vec2(INITIAL_CUE_SPEED, 0.0);

	balls[0].omegaY = INITIAL_CUE_SPEED / BALL_RADIUS;

	const double spacing = 2.01 * BALL_RADIUS;
	const double startX = 0.25;
	int index = 1;

	int rowCounts[4] = { 1, 2, 3, 3 };

	for (int row = 0; row < 4; ++row) {
		int count = rowCounts[row];

		double x = startX + row * spacing;
 

		for (int col = 0; col < count; ++col) {
			if (index >= BALL_COUNT)
				break;

			double z = (col - (count - 1) * 0.5) * spacing;

			balls[index].pos = Vec2(x, z);
			balls[index].vel = Vec2(0.0, 0.0);
			balls[index].omegaY = 0.0;

			index++;
		} 

	}
} 
void resetSimulationCounters() {
	simulationTime = 0.0;
	physicsCalculationTime = 0.0;
	renderingTime = 0.0;
	totalFrameCount = 0;

	realStartTime = getRealTimeSeconds();
	realEndTime = 0.0;

	simulationFinished = false;
	resultPrinted = false;
	totalPhysicsSteps = 0;
	totalCollisionChecks = 0;

	physicsStepsPerSecond = 0.0;
	simulatedSecondsPerSecond = 0.0;
}

void resetSimulation() {
	createBalls();
	resetSimulationCounters();
} 
void resolveBallBallCollision(int i, int j) {

	Ball& A = balls[i];
	Ball& B = balls[j];

	Vec2 delta = B.pos - A.pos;
	double dist = length2(delta);
	double minDist = 2.0 * BALL_RADIUS;

	if (dist <= 0.0 || dist >= minDist)
		return;

	Vec2 n = delta / dist;
	Vec2 t = Vec2(-n.z, n.x);

	double penetration = minDist - dist;
	A.pos -= n * (penetration * 0.5);
	B.pos += n * (penetration * 0.5);

	Vec2 rv = B.vel - A.vel;
	double vn = dot2(rv, n);

	if (vn > 0.0)
		return;

	double invMass = 1.0 / BALL_MASS;
	double jn = -(1.0 + RESTITUTION) * vn / (invMass + invMass);

	Vec2 normalImpulse = n * jn;
	A.vel -= normalImpulse * invMass;
	B.vel += normalImpulse * invMass;

	rv = B.vel - A.vel;
	double vt = dot2(rv, t);

	double jt = -vt / (invMass + invMass);
	double maxFrictionImpulse = BALL_BALL_MU * jn;

	if (jt > maxFrictionImpulse) jt = maxFrictionImpulse;
	if (jt < -maxFrictionImpulse) jt = -maxFrictionImpulse;

	Vec2 frictionImpulse = t * jt;
	A.vel -= frictionImpulse * invMass;
	B.vel += frictionImpulse * invMass;

	double inertia = INERTIA_COEFF * BALL_MASS * BALL_RADIUS * BALL_RADIUS;
	double angularImpulse = BALL_RADIUS * jt;

	A.omegaY -= angularImpulse / inertia;
	B.omegaY += angularImpulse / inertia;
}

void updateBall(Ball& b, double dt) {
	double speed = length2(b.vel);

	if (speed < STOP_SPEED) {
		b.vel = Vec2(0, 0);
		b.omegaY = 0;
		return;
	}

	Vec2 dir = normalize2(b.vel);

	double expectedOmega = speed / BALL_RADIUS;
	double rollingError = std::fabs(std::fabs(b.omegaY) - expectedOmega);

	double muTable;

	if (rollingError < 0.5) {
		muTable = ROLLING_FRICTION;
	}
	else {
		muTable = SLIDING_TABLE_MU;
	}

	const double g = 9.81;
	double newSpeed = speed - muTable * g * dt;

	if (newSpeed < 0.0)
		newSpeed = 0.0;

	b.vel = dir * newSpeed;

	double targetOmega = newSpeed / BALL_RADIUS;

	if (b.omegaY >= 0.0)
		b.omegaY = 0.95 * b.omegaY + 0.05 * targetOmega;
	else
		b.omegaY = 0.95 * b.omegaY - 0.05 * targetOmega;

	b.pos += b.vel * dt;

	b.rotAngle += (newSpeed / BALL_RADIUS) * dt * 180.0 / PI;

	double halfL = TABLE_LENGTH * 0.5 - BALL_RADIUS;
	double halfW = TABLE_WIDTH * 0.5 - BALL_RADIUS;

	if (b.pos.x < -halfL) {
		b.pos.x = -halfL;
		b.vel.x = -b.vel.x * CUSHION_RESTITUTION;
	}

	if (b.pos.x > halfL) {
		b.pos.x = halfL;
		b.vel.x = -b.vel.x * CUSHION_RESTITUTION;
	}

	if (b.pos.z < -halfW) {
		b.pos.z = -halfW;
		b.vel.z = -b.vel.z * CUSHION_RESTITUTION;
	}

	if (b.pos.z > halfW) {
		b.pos.z = halfW;
		b.vel.z = -b.vel.z * CUSHION_RESTITUTION;
	}
} 
int findNearestObjectBallToCue()
{
	int nearestIndex = -1;
	double nearestDist = 1e9;

	for (int i = 1; i < BALL_COUNT; ++i)
	{
		double d = length2(balls[i].pos - balls[0].pos);

		if (d < nearestDist)
		{
			nearestDist = d;
			nearestIndex = i;
		}
	}

	return nearestIndex;
} 
void hitCueBallToNearestBall()
{
	int target = findNearestObjectBallToCue();

	if (target == -1)
		return;

	Vec2 direction = normalize2(balls[target].pos - balls[0].pos);
 
	balls[0].vel = direction * EXTRA_HIT_SPEED;
	balls[0].omegaY = EXTRA_HIT_SPEED / BALL_RADIUS;
}



bool allBallsStopped() {
	for (int i = 0; i < BALL_COUNT; ++i) {
		if (length2(balls[i].vel) > STOP_SPEED)
			return false;
	}

	return true;
}


void printResultsOnce() {

	if (resultPrinted)
		return;

	realEndTime = getRealTimeSeconds();
	double realExecutionTime = realEndTime - realStartTime;


	if (realExecutionTime > 0.000001) {
		physicsStepsPerSecond = (double)totalPhysicsSteps / realExecutionTime;
		simulatedSecondsPerSecond = simulationTime / realExecutionTime;
	}
	else {
		physicsStepsPerSecond = 0.0;
		simulatedSecondsPerSecond = 0.0;
	}
	printf("\n");

	resultPrinted = true;


	avgPhysicsSteps += physicsStepsPerSecond;
	avgSimSeconds += simulatedSecondsPerSecond;
	avgPhysicsTime += physicsCalculationTime;
	avgRenderingTime += renderingTime;

	totalFrameCountSum += totalFrameCount;
	totalPhysicsStepsSum += totalPhysicsSteps;
	currentRun++;
 
	if (currentRun < TOTAL_RUNS)
	{
		resetSimulation();
		return;
	}
	printf("SERIAL BILLIARD RESULTS:\n");
	printf("Physics Steps/s                    : %.3f\n", avgPhysicsSteps / TOTAL_RUNS);
	printf("Rendering time                     : %.6f \n", avgRenderingTime / TOTAL_RUNS);

	fflush(stdout);
	exit(0);

}

void serialPhysicsStep(double dt) {
	if (simulationFinished)
		return;

	double now = getRealTimeSeconds();
	double elapsedRealTime = now - realStartTime;

	if (elapsedRealTime >= BENCHMARK_DURATION_SECONDS) {
		simulationFinished = true;
		return;
	}

	double physicsStart = getRealTimeSeconds();
 
	for (int i = 0; i < BALL_COUNT; ++i) {
		for (int j = i + 1; j < BALL_COUNT; ++j) {
			resolveBallBallCollision(i, j);
		}
	}
 
	for (int i = 0; i < BALL_COUNT; ++i) {
		updateBall(balls[i], dt);
	}

	double physicsEnd = getRealTimeSeconds();
	physicsCalculationTime += (physicsEnd - physicsStart);

	simulationTime += dt;

	totalPhysicsSteps++;
 
	if (allBallsStopped()) {
		hitCueBallToNearestBall();
	}

	now = getRealTimeSeconds();
	elapsedRealTime = now - realStartTime;

	if (elapsedRealTime >= BENCHMARK_DURATION_SECONDS) {
		simulationFinished = true;
	}
}
 
void setMaterial(float r, float g, float b, float shininess) {
 
	GLfloat ambient[] = { r * 0.45f, g * 0.45f, b * 0.45f, 1.0f };

	GLfloat diffuse[] = { r, g, b, 1.0f };

	GLfloat specular[] = { 0.05f, 0.05f, 0.05f, 1.0f };

	glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
	glMaterialf(GL_FRONT, GL_SHININESS, shininess);

}

void drawTable() {
 
	setMaterial(0.01f, 0.22f, 0.08f, 20.0f);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f((float)-TABLE_LENGTH / 2, 0, (float)-TABLE_WIDTH / 2);
	glVertex3f((float)TABLE_LENGTH / 2, 0, (float)-TABLE_WIDTH / 2);
	glVertex3f((float)TABLE_LENGTH / 2, 0, (float)TABLE_WIDTH / 2);
	glVertex3f((float)-TABLE_LENGTH / 2, 0, (float)TABLE_WIDTH / 2);
	glEnd();

	setMaterial(0.35f, 0.15f, 0.05f, 35.0f);

	double rail = 0.08;
	double h = 0.035;

	glPushMatrix();
	glTranslated(0, h / 2, -TABLE_WIDTH / 2 - rail / 2);
	glScaled(TABLE_LENGTH + 2 * rail, h, rail);
	glutSolidCube(1.0);
	glPopMatrix();

	glPushMatrix();
	glTranslated(0, h / 2, TABLE_WIDTH / 2 + rail / 2);
	glScaled(TABLE_LENGTH + 2 * rail, h, rail);
	glutSolidCube(1.0);
	glPopMatrix();

	glPushMatrix();
	glTranslated(-TABLE_LENGTH / 2 - rail / 2, h / 2, 0);
	glScaled(rail, h, TABLE_WIDTH);
	glutSolidCube(1.0);
	glPopMatrix();

	glPushMatrix();
	glTranslated(TABLE_LENGTH / 2 + rail / 2, h / 2, 0);
	glScaled(rail, h, TABLE_WIDTH);
	glutSolidCube(1.0);
	glPopMatrix();
}

void drawBall(const Ball& b) {

	glPushMatrix();

	glTranslated(b.pos.x, BALL_RADIUS, b.pos.z);

	glRotated(b.rotAngle, 0, 0, 1);

	setMaterial(b.color[0], b.color[1], b.color[2], 20.0f);
	glutSolidSphere(BALL_RADIUS, 50, 50);

	glPopMatrix();

}
void display() {

	if (!resultPrinted) {
		totalFrameCount++;
	}

	double renderStart = getRealTimeSeconds();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	gluLookAt(
		0.0, 2.5, 1.25,
		0.0, 0.0, 0.0,
		0.0, 1.0, 0.0
	); 
	drawTable();

	for (int i = 0; i < BALL_COUNT; ++i) {
		drawBall(balls[i]);
	}

	glutSwapBuffers();


	double renderEnd = getRealTimeSeconds();

	if (!resultPrinted) {
		renderingTime += (renderEnd - renderStart);
	}

	if (simulationFinished && !resultPrinted) {
		printResultsOnce();
	}
}

void reshape(int w, int h) {

	if (h == 0)
		h = 1;

	windowW = w;
	windowH = h;

	glViewport(0, 0, w, h);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(50.0, (double)w / (double)h, 0.01, 20.0);

	glMatrixMode(GL_MODELVIEW); 
}

void idle() {
	 
	static int lastTime = glutGet(GLUT_ELAPSED_TIME);
	int now = glutGet(GLUT_ELAPSED_TIME);

	double elapsed = (now - lastTime) / 1000.0;
	lastTime = now;

	static double accumulator = 0.0; 
	if (!simulationFinished)
	{
		accumulator += elapsed;

		while (accumulator >= TIME_STEP * PHYSICS_STEPS_PER_FRAME
			&& !simulationFinished)
		{
			for (int i = 0; i < PHYSICS_STEPS_PER_FRAME; i++)
			{
				serialPhysicsStep(TIME_STEP);

				if (simulationFinished)
					break;
			}

			accumulator -= TIME_STEP * PHYSICS_STEPS_PER_FRAME;
		}
	}

	glutPostRedisplay();
}

void keyboard(unsigned char key, int, int) {
	if (key == 27)
		exit(0);

	if (key == 'r' || key == 'R') {
		resetSimulation();
	}
}

void initOpenGL() {
	 

	glClearColor(0.04f, 0.06f, 0.07f, 1.0f);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);

	glShadeModel(GL_SMOOTH);

	GLfloat lightPos[] = { 0.0f, 2.5f, 1.5f, 1.0f };
	GLfloat lightAmb[] = { 0.45f, 0.45f, 0.45f, 1.0f };
	GLfloat lightDif[] = { 1.00f, 1.00f, 1.00f, 1.0f };
	GLfloat lightSpe[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDif);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpe);
}

int main(int argc, char** argv) {

	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	glutInitWindowSize(windowW, windowH);
	glutCreateWindow("Serial Billiard Simulation ");

	initOpenGL();

	resetSimulation();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(idle);
	glutKeyboardFunc(keyboard);

	glutMainLoop();

	return 0;
}