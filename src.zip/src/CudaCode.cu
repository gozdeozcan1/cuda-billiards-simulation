#define _CRT_SECURE_NO_WARNINGS
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <chrono>

#define CUDA_CHECK(x) do {  \
cudaError_t err = (x);  \
if (err != cudaSuccess) {   \
printf("CUDA error: %s at line %d\n",   \
cudaGetErrorString(err), __LINE__); \
system("pause");   \
exit(1);\
}   \
} while (0)

#define CUDA_THREADS_PER_BLOCK 256
#define COLLISION_PAIR_COUNT   (BALL_COUNT * (BALL_COUNT - 1) / 2)
#define PI_F   3.14f

#define BALL_RADIUS 0.0305f
#define BALL_MASS  0.205f
#define INERTIA_COEFF  (2.0f / 5.0f)

#define BALL_BALL_MU   0.05f
#define RESTITUTION 0.95f

#define ROLLING_FRICTION   0.01f
#define SLIDING_TABLE_MU   0.10f

#define INITIAL_CUE_SPEED  0.80f
#define EXTRA_HIT_SPEED 0.80f

#define TABLE_LENGTH   2.40f
#define TABLE_WIDTH 1.20f
#define CUSHION_RESTITUTION 0.96f
#define STOP_SPEED 0.004f
#define TIME_STEP  (1.0f / 240.0f)

#define SPHERE_STACKS  18
#define SPHERE_SLICES  36
#define SPHERE_TRIANGLES   (SPHERE_STACKS * SPHERE_SLICES * 2)
#define SPHERE_VERTS_PER_BALL  (SPHERE_TRIANGLES * 3)

#define BADGE_SEGMENTS 40
#define BADGE_VERTS_PER_BALL   (BADGE_SEGMENTS * 3)

#define DIGIT_SEGMENTS_PER_DIGIT 7
#define DIGIT_VERTS_PER_SEGMENT  2
#define MAX_DIGITS_PER_BALL  2
#define DIGIT_VERTS_PER_BALL (DIGIT_SEGMENTS_PER_DIGIT * DIGIT_VERTS_PER_SEGMENT * MAX_DIGITS_PER_BALL)

#define TOTAL_SPHERE_VERTS (BALL_COUNT * SPHERE_VERTS_PER_BALL)
#define TOTAL_BADGE_VERTS  ((BALL_COUNT - 1) * BADGE_VERTS_PER_BALL)
#define TOTAL_DIGIT_VERTS  ((BALL_COUNT - 1) * DIGIT_VERTS_PER_BALL)
#define TABLE_TOP_VERTS 6
#define BOX_VERTS  36
#define TABLE_RAIL_VERTS   (4 * BOX_VERTS)
#define TOTAL_TABLE_VERTS  (TABLE_TOP_VERTS + TABLE_RAIL_VERTS )
#define BALL_COUNT 10
#define BENCHMARK_DURATION_SECONDS 50.0

int windowW = 1280;
int windowH = 720;
const int PHYSICS_STEPS_PER_FRAME = 3;
double simulationTime = 0.0;

double realStartTime = 0.0;
double realEndTime = 0.0;
long long totalPhysicsStepCount = 0;
double physicsStepsPerSecond = 0.0;
double simulatedSecondsPerSecond = 0.0;
double physicsCalculationTime = 0.0;
double renderingTime = 0.0;
bool hostSimulationFinished = false;
bool resultPrinted = false;
int currentRun = 0;
double avgPhysicsSteps = 0.0;
double avgSimSeconds = 0.0;
double avgPhysicsTime = 0.0;
double avgRenderingTime = 0.0;

const int TOTAL_RUNS = 1;
struct BallGPU {
float2 pos;
float2 vel;
float omegaY;
float rotAngle;
float4 color;
};

struct VertexGPU {
float4 pos;
float4 normal;
float4 color;
};

BallGPU h_balls[BALL_COUNT];
BallGPU* d_balls = nullptr;

int* d_simulationFinished = nullptr;

int* h_finishedMapped = nullptr;
int* d_finishedMapped = nullptr;

float2* d_deltaVel = nullptr;
float2* d_deltaPos = nullptr;
float* d_deltaOmega = nullptr;

GLuint sphereVBO = 0;
GLuint tableVBO = 0;

cudaGraphicsResource* cudaSphereResource = nullptr;
cudaGraphicsResource* cudaTableResource = nullptr;
void resetSimulation();

__device__ float dot2(float2 a, float2 b) {
return a.x * b.x + a.y * b.y;
}

__device__ float length2(float2 a) {
return sqrtf(dot2(a, a));
}

__device__ float2 add2(float2 a, float2 b) {
return make_float2(a.x + b.x, a.y + b.y);
}

__device__ float2 sub2(float2 a, float2 b) {
return make_float2(a.x - b.x, a.y - b.y);
}

__device__ float2 mul2(float2 a, float s) {
return make_float2(a.x * s, a.y * s);
}

__device__ float2 normalize2(float2 a) {
float len = length2(a);
if (len < 1e-8f)
return make_float2(1.0f, 0.0f);
return make_float2(a.x / len, a.y / len);
}

__device__ float3 add3(float3 a, float3 b) {
return make_float3(a.x + b.x, a.y + b.y, a.z + b.z);
}

__device__ float3 mul3(float3 a, float s) {
return make_float3(a.x * s, a.y * s, a.z * s);
}

__device__ float3 normalize3(float3 a) {
float len = sqrtf(a.x * a.x + a.y * a.y + a.z * a.z);
if (len < 1e-8f)
return make_float3(0.0f, 1.0f, 0.0f);
return make_float3(a.x / len, a.y / len, a.z / len);
}

__device__ float3 spherePoint(float theta, float phi) {
float st = sinf(theta);
float ct = cosf(theta);
float sp = sinf(phi);
float cp = cosf(phi);

return make_float3(st * cp, ct, st * sp);
}

__device__ void writeVertex(VertexGPU* out, int idx, float3 p, float3 n, float4 c) {
out[idx].pos = make_float4(p.x, p.y, p.z, 1.0f);
out[idx].normal = make_float4(n.x, n.y, n.z, 0.0f);
out[idx].color = c;
}

__device__ void updateBall(BallGPU& b, float dt) {
float speed = length2(b.vel);

if (speed < STOP_SPEED) {
b.vel = make_float2(0.0f, 0.0f);
b.omegaY = 0.0f;
return;
}

float2 dir = normalize2(b.vel);

float expectedOmega = speed / BALL_RADIUS;
float rollingError = fabsf(fabsf(b.omegaY) - expectedOmega);

float muTable = (rollingError < 0.5f) ? ROLLING_FRICTION : SLIDING_TABLE_MU;;

float newSpeed = speed - muTable * 9.81f * dt;

if (newSpeed < 0.0f)
newSpeed = 0.0f;

b.vel = mul2(dir, newSpeed);

float targetOmega = newSpeed / BALL_RADIUS;

if (b.omegaY >= 0.0f)
b.omegaY = 0.95f * b.omegaY + 0.05f * targetOmega;
else
b.omegaY = 0.95f * b.omegaY - 0.05f * targetOmega;

b.pos = add2(b.pos, mul2(b.vel, dt));
b.rotAngle += (newSpeed / BALL_RADIUS) * dt * 180.0f / PI_F;

float halfL = TABLE_LENGTH * 0.5f - BALL_RADIUS;
float halfW = TABLE_WIDTH * 0.5f - BALL_RADIUS;

if (b.pos.x < -halfL) {
b.pos.x = -halfL;
b.vel.x = -b.vel.x * CUSHION_RESTITUTION;
}

if (b.pos.x > halfL) {
b.pos.x = halfL;
b.vel.x = -b.vel.x * CUSHION_RESTITUTION;
}

if (b.pos.y < -halfW) {
b.pos.y = -halfW;
b.vel.y = -b.vel.y * CUSHION_RESTITUTION;
}

if (b.pos.y > halfW) {
b.pos.y = halfW;
b.vel.y = -b.vel.y * CUSHION_RESTITUTION;
}
}

__device__ bool allStoppedGPU(BallGPU* balls) {
for (int i = 0; i < BALL_COUNT; i++) {
if (length2(balls[i].vel) > STOP_SPEED)
return false;
}
return true;
}

__device__ int findNearestBallGPU(BallGPU* balls) {
int nearest = 1;
float nearestDist = 1e9f;

for (int i = 1; i < BALL_COUNT; i++) {
float d = length2(sub2(balls[i].pos, balls[0].pos));
if (d < nearestDist) {
nearestDist = d;
nearest = i;
}
}

return nearest;
}

__device__ void hitCueBallGPU(BallGPU* balls) {
int target = findNearestBallGPU(balls);
float2 direction = normalize2(sub2(balls[target].pos, balls[0].pos));

balls[0].vel = mul2(direction, EXTRA_HIT_SPEED);
balls[0].omegaY = EXTRA_HIT_SPEED / BALL_RADIUS;
}
__global__ void collisionPairsKernel(
BallGPU* balls,
float2* deltaVel,
float2* deltaPos,
float* deltaOmega,
int* simulationFinished)
{
if (*simulationFinished)
return;

int pairId = blockIdx.x * blockDim.x + threadIdx.x;

if (pairId >= COLLISION_PAIR_COUNT)
return;

int count = 0;
int i = 0;
int j = 1;

for (int a = 0; a < BALL_COUNT; a++) {
for (int b = a + 1; b < BALL_COUNT; b++) {
if (count == pairId) {
i = a;
j = b;
}
count++;
}
}

BallGPU A = balls[i];
BallGPU B = balls[j];

float2 delta = sub2(B.pos, A.pos);
float dist = length2(delta);
float minDist = 2.0f * BALL_RADIUS;

if (dist <= 0.0f || dist >= minDist)
return;

float2 n = make_float2(delta.x / dist, delta.y / dist);
float2 t = make_float2(-n.y, n.x);

float penetration = minDist - dist;

atomicAdd(&deltaPos[i].x, -n.x * penetration * 0.5f);
atomicAdd(&deltaPos[i].y, -n.y * penetration * 0.5f);
atomicAdd(&deltaPos[j].x, n.x * penetration * 0.5f);
atomicAdd(&deltaPos[j].y, n.y * penetration * 0.5f);

float2 rv = sub2(B.vel, A.vel);
float vn = dot2(rv, n);

if (vn > 0.0f)
return;

float invMass = 1.0f / BALL_MASS;
float jn = -(1.0f + RESTITUTION) * vn / (invMass + invMass);

float2 normalImpulse = mul2(n, jn);

atomicAdd(&deltaVel[i].x, -normalImpulse.x * invMass);
atomicAdd(&deltaVel[i].y, -normalImpulse.y * invMass);
atomicAdd(&deltaVel[j].x, normalImpulse.x * invMass);
atomicAdd(&deltaVel[j].y, normalImpulse.y * invMass);

float vt = dot2(rv, t);
float jt = -vt / (invMass + invMass);
float maxFrictionImpulse = BALL_BALL_MU * jn;

if (jt > maxFrictionImpulse) jt = maxFrictionImpulse;
if (jt < -maxFrictionImpulse) jt = -maxFrictionImpulse;

float2 frictionImpulse = mul2(t, jt);

atomicAdd(&deltaVel[i].x, -frictionImpulse.x * invMass);
atomicAdd(&deltaVel[i].y, -frictionImpulse.y * invMass);
atomicAdd(&deltaVel[j].x, frictionImpulse.x * invMass);
atomicAdd(&deltaVel[j].y, frictionImpulse.y * invMass);

float inertia = INERTIA_COEFF * BALL_MASS * BALL_RADIUS * BALL_RADIUS;
float angularImpulse = BALL_RADIUS * jt;

atomicAdd(&deltaOmega[i], -angularImpulse / inertia);
atomicAdd(&deltaOmega[j], angularImpulse / inertia);
}

__global__ void applyCollisionDeltasKernel(
BallGPU* balls,
float2* deltaVel,
float2* deltaPos,
float* deltaOmega)
{
int i = blockIdx.x * blockDim.x + threadIdx.x;

if (i >= BALL_COUNT)
return;

balls[i].pos = add2(balls[i].pos, deltaPos[i]);
balls[i].vel = add2(balls[i].vel, deltaVel[i]);
balls[i].omegaY += deltaOmega[i];
}

__global__ void updateBallsKernel(BallGPU* balls, int* simulationFinished)
{
if (*simulationFinished)
return;

int i = blockIdx.x * blockDim.x + threadIdx.x;

if (i >= BALL_COUNT)
return;

updateBall(balls[i], TIME_STEP);
}

__global__ void finishStepKernel(
BallGPU* balls,
int* simulationFinished,
int* finishedMappedFlag)
{
if (*simulationFinished) {
*finishedMappedFlag = 1;
return;
}

if (allStoppedGPU(balls)) {
hitCueBallGPU(balls);
}
}

__global__ void generateSphereKernel(BallGPU* balls, VertexGPU* sphereVerts) {
int globalId = blockIdx.x * blockDim.x + threadIdx.x;
int total = TOTAL_SPHERE_VERTS;

if (globalId >= total)
return;

int ballId = globalId / SPHERE_VERTS_PER_BALL;
int local = globalId % SPHERE_VERTS_PER_BALL;

int tri = local / 3;
int corner = local % 3;

int cell = tri / 2;
int triInCell = tri % 2;

int stack = cell / SPHERE_SLICES;
int slice = cell % SPHERE_SLICES;

float theta0 = PI_F * (float)stack / (float)SPHERE_STACKS;
float theta1 = PI_F * (float)(stack + 1) / (float)SPHERE_STACKS;

float phi0 = 2.0f * PI_F * (float)slice / (float)SPHERE_SLICES;
float phi1 = 2.0f * PI_F * (float)(slice + 1) / (float)SPHERE_SLICES;

float3 p00 = spherePoint(theta0, phi0);
float3 p01 = spherePoint(theta0, phi1);
float3 p10 = spherePoint(theta1, phi0);
float3 p11 = spherePoint(theta1, phi1);

float3 n;

if (triInCell == 0) {
if (corner == 0) n = p00;
if (corner == 1) n = p10;
if (corner == 2) n = p11;
}
else {
if (corner == 0) n = p00;
if (corner == 1) n = p11;
if (corner == 2) n = p01;
}

BallGPU b = balls[ballId];

float3 center = make_float3(b.pos.x, BALL_RADIUS, b.pos.y);
float3 pos = add3(center, mul3(n, BALL_RADIUS));

writeVertex(sphereVerts, globalId, pos, normalize3(n), b.color);
}

__device__ void writeTableVertex(VertexGPU* out, int idx, float3 p, float3 n, float4 c) {
out[idx].pos = make_float4(p.x, p.y, p.z, 1.0f);



out[idx].normal = make_float4(n.x, n.y, n.z, 0.0f);



out[idx].color = c;

}
__device__ float3 boxCorner(
float cx, float cy, float cz,
float sx, float sy, float sz,
int corner)
{
float x = (corner & 1) ? 0.5f : -0.5f;



float y = (corner & 2) ? 0.5f : -0.5f;



float z = (corner & 4) ? 0.5f : -0.5f;



return make_float3(
cx + x * sx,
cy + y * sy,
cz + z * sz
);


}

__device__ void boxVertexByLocal(
int local,
float cx, float cy, float cz,
float sx, float sy, float sz,
float3& p,
float3& n)
{

const int triCorners[36] = {
1,5,7, 1,7,3,
0,2,6, 0,6,4,
2,3,7, 2,7,6,
0,4,5, 0,5,1,
4,6,7, 4,7,5,
0,1,3, 0,3,2
};

const int face = local / 6;

if (face == 0)
n = make_float3(1, 0, 0);

else if (face == 1)
n = make_float3(-1, 0, 0);

else if (face == 2)
n = make_float3(0, 1, 0);

else if (face == 3)
n = make_float3(0, -1, 0);

else if (face == 4)
n = make_float3(0, 0, 1);

else
n = make_float3(0, 0, -1);

p = boxCorner(
cx, cy, cz,
sx, sy, sz,
triCorners[local]
);
}

__global__ void generateTableKernel(VertexGPU* tableVerts) {
int id = blockIdx.x * blockDim.x + threadIdx.x;


if (id >= TOTAL_TABLE_VERTS) return;


float4 clothColor = make_float4(0.01f, 0.22f, 0.08f, 1.0f);


float4 railColor = make_float4(0.35f, 0.15f, 0.05f, 1.0f);



if (id < TABLE_TOP_VERTS) {
int c = id;
float x0 = -TABLE_LENGTH * 0.5f;
float x1 = TABLE_LENGTH * 0.5f;
float z0 = -TABLE_WIDTH * 0.5f;
float z1 = TABLE_WIDTH * 0.5f;
float3 p;
if (c == 0) p = make_float3(x0, 0.0f, z0);
if (c == 1) p = make_float3(x1, 0.0f, z0);
if (c == 2) p = make_float3(x1, 0.0f, z1);
if (c == 3) p = make_float3(x0, 0.0f, z0);
if (c == 4) p = make_float3(x1, 0.0f, z1);
if (c == 5) p = make_float3(x0, 0.0f, z1);
writeTableVertex(tableVerts, id, p, make_float3(0, 1, 0), clothColor);
return;

}

int localRailGlobal = id - TABLE_TOP_VERTS;

if (localRailGlobal < TABLE_RAIL_VERTS) {
int railId = localRailGlobal / BOX_VERTS;
int local = localRailGlobal % BOX_VERTS;
float rail = 0.08f;
float h = 0.035f;
float cx = 0.0f, cy = h * 0.5f, cz = 0.0f;
float sx = TABLE_LENGTH, sy = h, sz = TABLE_WIDTH;
if (railId == 0) {
cx = 0.0f; cy = h * 0.5f; cz = -TABLE_WIDTH * 0.5f - rail * 0.5f;
sx = TABLE_LENGTH + 2.0f * rail; sy = h; sz = rail;
}
if (railId == 1) {
cx = 0.0f; cy = h * 0.5f; cz = TABLE_WIDTH * 0.5f + rail * 0.5f;
sx = TABLE_LENGTH + 2.0f * rail; sy = h; sz = rail;
}
if (railId == 2) {
cx = -TABLE_LENGTH * 0.5f - rail * 0.5f; cy = h * 0.5f; cz = 0.0f;
sx = rail; sy = h; sz = TABLE_WIDTH;
}
if (railId == 3) {
cx = TABLE_LENGTH * 0.5f + rail * 0.5f; cy = h * 0.5f; cz = 0.0f;
sx = rail; sy = h; sz = TABLE_WIDTH;
}
float3 p, n;
boxVertexByLocal(local, cx, cy, cz, sx, sy, sz, p, n);
writeTableVertex(tableVerts, id, p, n, railColor);
return;

}
}
double getRealTimeSeconds()
{
using namespace std::chrono;

static auto start =
high_resolution_clock::now();

auto now =
high_resolution_clock::now();

return duration<double>(now - start).count();
}

void resetSimulationCounters() {
simulationTime = 0.0;
physicsCalculationTime = 0.0;
renderingTime = 0.0;

totalPhysicsStepCount = 0;
physicsStepsPerSecond = 0.0;
simulatedSecondsPerSecond = 0.0;

realStartTime = getRealTimeSeconds();
realEndTime = 0.0;

hostSimulationFinished = false;
resultPrinted = false;
}

void printResultsOnce() {
if (resultPrinted)
return;

realEndTime = getRealTimeSeconds();
double realExecutionTime = realEndTime - realStartTime;

if (realExecutionTime > 0.000001) {
physicsStepsPerSecond = (double)totalPhysicsStepCount / realExecutionTime;
simulatedSecondsPerSecond = simulationTime / realExecutionTime;
}
else {
physicsStepsPerSecond = 0.0;
simulatedSecondsPerSecond = 0.0;
}

resultPrinted = true;

avgPhysicsSteps += physicsStepsPerSecond;
avgRenderingTime += renderingTime;
currentRun++;

if (currentRun < TOTAL_RUNS)
{
resetSimulation();
return;
}

printf("CUDA BILLIARD RESULTS:\n");
printf("Physics Steps/s: %.3f\n", avgPhysicsSteps / TOTAL_RUNS);
printf("Rendering time : %.6f s\n", avgRenderingTime / TOTAL_RUNS);

fflush(stdout);
exit(0);

}


void setBallColor(int i) {

if (i == 0) {
h_balls[i].color = make_float4(1.0f, 1.0f, 1.0f, 1.0f);
return;
}

float colors[9][3] = {
{1.00f, 0.85f, 0.05f},
{0.05f, 0.20f, 0.95f},
{0.95f, 0.10f, 0.10f},
{0.45f, 0.05f, 0.70f},
{1.00f, 0.45f, 0.02f},
{0.05f, 0.55f, 0.15f},
{0.60f, 0.10f, 0.05f},
{0.20f, 0.20f, 0.80f} ,
{0.95f, 0.50f, 0.95f}
};

h_balls[i].color = make_float4(
colors[i - 1][0],
colors[i - 1][1],
colors[i - 1][2],
1.0f
);
}

void createBallsHost() {
for (int i = 0; i < BALL_COUNT; i++) {
h_balls[i].pos = make_float2(0.0f, 0.0f);
h_balls[i].vel = make_float2(0.0f, 0.0f);
h_balls[i].omegaY = 0.0f;
h_balls[i].rotAngle = 0.0f;
setBallColor(i);
}

h_balls[0].pos = make_float2(-0.80f, 0.0f);
h_balls[0].vel = make_float2(INITIAL_CUE_SPEED, 0.0f);
h_balls[0].omegaY = INITIAL_CUE_SPEED / BALL_RADIUS;
const float spacing = 2.01f * BALL_RADIUS;
const float startX = 0.25f;
int index = 1;
int rowCounts[4] = { 1, 2, 3, 3 };

for (int row = 0; row < 4; row++) {
int count = rowCounts[row];
float x = startX + row * spacing;
for (int col = 0; col < count; col++) {
if (index >= BALL_COUNT)
break;
float z = (col - (count - 1) * 0.5f) * spacing;
h_balls[index].pos = make_float2(x, z);
h_balls[index].vel = make_float2(0.0f, 0.0f);
h_balls[index].omegaY = 0.0f;index++;}
}
}
void createInteropVBO(GLuint* vbo, cudaGraphicsResource** resource, size_t bytes) {
glGenBuffers(1, vbo);

glBindBuffer(GL_ARRAY_BUFFER, *vbo);

glBufferData(GL_ARRAY_BUFFER, bytes, nullptr, GL_DYNAMIC_DRAW);

glBindBuffer(GL_ARRAY_BUFFER, 0);

CUDA_CHECK(cudaGraphicsGLRegisterBuffer(
resource,
*vbo,
cudaGraphicsMapFlagsWriteDiscard
));
}
void createVBOs() {
createInteropVBO(
&sphereVBO,
&cudaSphereResource,
TOTAL_SPHERE_VERTS * sizeof(VertexGPU)
);


createInteropVBO(
&tableVBO,
&cudaTableResource,
TOTAL_TABLE_VERTS * sizeof(VertexGPU)
);

}

void initCUDA() {

CUDA_CHECK(cudaSetDevice(0));

CUDA_CHECK(cudaMalloc((void**)&d_balls,
BALL_COUNT * sizeof(BallGPU)));

CUDA_CHECK(cudaMalloc((void**)&d_simulationFinished,
sizeof(int)));

CUDA_CHECK(cudaHostAlloc((void**)&h_finishedMapped,
sizeof(int),
cudaHostAllocMapped));


CUDA_CHECK(cudaHostGetDevicePointer(
(void**)&d_finishedMapped,
h_finishedMapped,
0));

CUDA_CHECK(cudaMalloc((void**)&d_deltaVel,
BALL_COUNT * sizeof(float2)));

CUDA_CHECK(cudaMalloc((void**)&d_deltaPos,
BALL_COUNT * sizeof(float2)));

CUDA_CHECK(cudaMalloc((void**)&d_deltaOmega,
BALL_COUNT * sizeof(float)));

}
void resetSimulation() {

createBallsHost();

int zero = 0;

CUDA_CHECK(cudaMemcpy(d_balls, h_balls, BALL_COUNT * sizeof(BallGPU), cudaMemcpyHostToDevice));

CUDA_CHECK(cudaMemcpy(d_simulationFinished, &zero, sizeof(int), cudaMemcpyHostToDevice));

if (h_finishedMapped) {
*h_finishedMapped = 0;

}

CUDA_CHECK(cudaMemset(d_deltaVel, 0, BALL_COUNT * sizeof(float2)));

CUDA_CHECK(cudaMemset(d_deltaPos, 0, BALL_COUNT * sizeof(float2)));

CUDA_CHECK(cudaMemset(d_deltaOmega, 0, BALL_COUNT * sizeof(float)));

resetSimulationCounters();

}

void generateStaticTableVBOOnce() {
VertexGPU* tablePtr = nullptr;
size_t tableBytes = 0;

CUDA_CHECK(cudaGraphicsMapResources(1, &cudaTableResource, 0));


CUDA_CHECK(cudaGraphicsResourceGetMappedPointer(
(void**)&tablePtr,
&tableBytes,
cudaTableResource
));

int threads = CUDA_THREADS_PER_BLOCK;

int tableBlocks = (TOTAL_TABLE_VERTS + threads - 1) / threads;
generateTableKernel <<<tableBlocks, threads >>> (tablePtr);

CUDA_CHECK(cudaGetLastError());

CUDA_CHECK(cudaDeviceSynchronize());

CUDA_CHECK(cudaGraphicsUnmapResources(1, &cudaTableResource, 0));
}
void runCudaAndUpdateVBOs() {
VertexGPU* spherePtr = nullptr;
size_t sphereBytes = 0;

if (!hostSimulationFinished) {
double elapsed = getRealTimeSeconds() - realStartTime;
if (elapsed >= BENCHMARK_DURATION_SECONDS) {
int one = 1;
CUDA_CHECK(cudaMemcpy(d_simulationFinished, &one, sizeof(int), cudaMemcpyHostToDevice));
if (h_finishedMapped) {
*h_finishedMapped = 1;}hostSimulationFinished = true;}
}

CUDA_CHECK(cudaGraphicsMapResources(1, &cudaSphereResource, 0));
CUDA_CHECK(cudaGraphicsResourceGetMappedPointer(
(void**)&spherePtr,
&sphereBytes,
cudaSphereResource
));

bool wasFinishedBeforeStep = hostSimulationFinished;

double physicsStart = getRealTimeSeconds();

CUDA_CHECK(cudaMemset(d_deltaVel, 0, BALL_COUNT * sizeof(float2)));

CUDA_CHECK(cudaMemset(d_deltaPos, 0, BALL_COUNT * sizeof(float2)));

CUDA_CHECK(cudaMemset(d_deltaOmega, 0, BALL_COUNT * sizeof(float)));

int physicsThreads = CUDA_THREADS_PER_BLOCK;

int collisionBlocks = (COLLISION_PAIR_COUNT + physicsThreads - 1) / physicsThreads;

int ballBlocks = (BALL_COUNT + physicsThreads - 1) / physicsThreads;

collisionPairsKernel <<<collisionBlocks, physicsThreads >>> (
d_balls,
d_deltaVel,
d_deltaPos,
d_deltaOmega,
d_simulationFinished
);

CUDA_CHECK(cudaGetLastError());

applyCollisionDeltasKernel <<<ballBlocks, physicsThreads >>> (
d_balls,
d_deltaVel,
d_deltaPos,
d_deltaOmega
);

CUDA_CHECK(cudaGetLastError());

updateBallsKernel <<<ballBlocks, physicsThreads >>> (
d_balls,
d_simulationFinished
);

CUDA_CHECK(cudaGetLastError());

finishStepKernel <<<1, 1 >>> (
d_balls,
d_simulationFinished,
d_finishedMapped
);

CUDA_CHECK(cudaGetLastError());

CUDA_CHECK(cudaDeviceSynchronize());

double physicsEnd = getRealTimeSeconds();

if (!wasFinishedBeforeStep && !hostSimulationFinished) {
physicsCalculationTime += (physicsEnd - physicsStart);
simulationTime += TIME_STEP;
totalPhysicsStepCount++;
}

hostSimulationFinished = (h_finishedMapped && *h_finishedMapped != 0);

int threads = CUDA_THREADS_PER_BLOCK;

int sphereBlocks = (TOTAL_SPHERE_VERTS + threads - 1) / threads;

generateSphereKernel <<<sphereBlocks, threads >>> (d_balls, spherePtr);

CUDA_CHECK(cudaGetLastError());

CUDA_CHECK(cudaDeviceSynchronize());

CUDA_CHECK(cudaGraphicsUnmapResources(1, &cudaSphereResource, 0));
}
void bindVertexGPUBuffer(GLuint vbo) {

glBindBuffer(GL_ARRAY_BUFFER, vbo);

glEnableClientState(GL_VERTEX_ARRAY);

glEnableClientState(GL_NORMAL_ARRAY);

glEnableClientState(GL_COLOR_ARRAY);

glVertexPointer(
4,
GL_FLOAT,
sizeof(VertexGPU),
(void*)offsetof(VertexGPU, pos)
);

glNormalPointer(
GL_FLOAT,
sizeof(VertexGPU),
(void*)offsetof(VertexGPU, normal)
);

glColorPointer(
4,
GL_FLOAT,
sizeof(VertexGPU),
(void*)offsetof(VertexGPU, color)
);

}
void unbindVertexGPUBuffer() {

glDisableClientState(GL_VERTEX_ARRAY);
glDisableClientState(GL_NORMAL_ARRAY);
glDisableClientState(GL_COLOR_ARRAY);

glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void drawCudaGeneratedTable() {

glEnable(GL_COLOR_MATERIAL);

glEnable(GL_LIGHTING);

bindVertexGPUBuffer(tableVBO);

glDrawArrays(
GL_TRIANGLES,
0,
TOTAL_TABLE_VERTS
);

unbindVertexGPUBuffer();
}
void drawCudaGeneratedGeometry() {

glEnable(GL_COLOR_MATERIAL);

glEnable(GL_LIGHTING);

bindVertexGPUBuffer(sphereVBO);

glDrawArrays(GL_TRIANGLES, 0, TOTAL_SPHERE_VERTS);

unbindVertexGPUBuffer();

glEnable(GL_DEPTH_TEST);

glEnable(GL_LIGHTING);
}

void display() {

double renderStart = getRealTimeSeconds();

glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glLoadIdentity();

gluLookAt(
0.0, 2.5, 1.25,
0.0, 0.0, 0.0,
0.0, 1.0, 0.0
);

;
;
;
;
;

drawCudaGeneratedTable();

drawCudaGeneratedGeometry();

glutSwapBuffers();

double renderEnd = getRealTimeSeconds();

if (!resultPrinted) {
renderingTime += (renderEnd - renderStart);
}

if (hostSimulationFinished && !resultPrinted) {
printResultsOnce();
}
}

void idle()
{
double elapsedBenchmarkTime =
getRealTimeSeconds() - realStartTime;

if (elapsedBenchmarkTime >= BENCHMARK_DURATION_SECONDS)
{
printResultsOnce();if (currentRun >= TOTAL_RUNS)
{
fflush(stdout);system("pause");exit(0);
}return;
}

if (!hostSimulationFinished)
{for (int step = 0; step < PHYSICS_STEPS_PER_FRAME; step++)
{
runCudaAndUpdateVBOs();
}
}

glutPostRedisplay();
}

void reshape(int w, int h) {

if (h == 0)
h = 1;

windowW = w;
windowH = h;

glViewport(0, 0, w, h);

glMatrixMode(GL_PROJECTION);
glLoadIdentity();

gluPerspective(50.0, (double)w / (double)h, 0.01, 20.0);


glMatrixMode(GL_MODELVIEW);

}
void keyboard(unsigned char key, int, int) {


if (key == 27)
exit(0);

if (key == 'r' || key == 'R')
resetSimulation();
}

void initOpenGL() {


glClearColor(0.04f, 0.06f, 0.07f, 1.0f);

glEnable(GL_DEPTH_TEST);
glEnable(GL_LIGHTING);
glEnable(GL_LIGHT0);
glEnable(GL_NORMALIZE);
glShadeModel(GL_SMOOTH);

GLfloat lightPos[] = { 0.0f, 2.5f, 1.5f, 1.0f };
GLfloat lightAmb[] = { 0.25f, 0.25f, 0.25f, 1.0f };
GLfloat lightDif[] = { 0.95f, 0.95f, 0.90f, 1.0f };
GLfloat lightSpe[] = { 1.0f, 1.0f, 1.0f, 1.0f };


glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDif);
glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpe);
}

void cleanup() {

if (cudaSphereResource)
cudaGraphicsUnregisterResource(cudaSphereResource);
if (cudaTableResource)
cudaGraphicsUnregisterResource(cudaTableResource);
if (sphereVBO)
glDeleteBuffers(1, &sphereVBO);
if (tableVBO)
glDeleteBuffers(1, &tableVBO);
if (d_balls)
CUDA_CHECK(cudaFree(d_balls));
if (d_simulationFinished)
CUDA_CHECK(cudaFree(d_simulationFinished));
if (h_finishedMapped)
CUDA_CHECK(cudaFreeHost(h_finishedMapped));
if (d_deltaVel)
CUDA_CHECK(cudaFree(d_deltaVel));
if (d_deltaPos)
CUDA_CHECK(cudaFree(d_deltaPos));
if (d_deltaOmega)
CUDA_CHECK(cudaFree(d_deltaOmega));
}
int main(int argc, char** argv) {


glutInit(&argc, argv);

glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

glutInitWindowSize(windowW, windowH);
glutCreateWindow("CUDA Billiard Simulation ");
glewInit();
initOpenGL();
initCUDA();

createVBOs();
generateStaticTableVBOOnce();
resetSimulation();

glutDisplayFunc(display);
glutReshapeFunc(reshape);
glutIdleFunc(idle);
glutKeyboardFunc(keyboard);

atexit(cleanup);

glutMainLoop();

return 0;
}